import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import java.util.ArrayList;
import javax.swing.text.BadLocationException;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.Color;

public class ScannerGUI {
    private JFrame frame;
    private JTextPane inputArea;
    private JFileChooser fileChooser;
    private File currentFile;
    private JLabel statusBar;
    private JTabbedPane outputTabs;
    private JSplitPane splitPane;
    private int memoryAddress = 0;
    
    
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
        "int", "float", "double", "char", "bool", "void", "if", "else", "String",
        "for", "while", "return", "do", "switch", "case", "default", "break",
        "continue", "struct", "class", "public", "private", "protected",
        "const", "static", "virtual", "override", "new", "delete", "this",
        "namespace", "using", "sizeof", "typedef","foreach","short","try","catch","finally", "auto"));

    private static final Set<String> OPERATORS = new HashSet<>(Arrays.asList(
        "=", "+", "-", "*", "/","%", "<", ">", "<=", ">=", "==", "!=", "&&", "||","++","--"));

    private static final Set<String> SEPARATORS = new HashSet<>(Arrays.asList(
        ";", ",", "(", ")", "{", "}", "[", "]"));

    private static final Set<String> DATA_TYPES = new HashSet<>(Arrays.asList(
        "int", "float", "double", "char", "bool", "void", "String"));


    private static Map<String, SymbolTableEntry> symbolTable = new LinkedHashMap<>();
    private static List<Token> tokens = new ArrayList<>();
    private static final Pattern ARRAY_DECL_PATTERN = Pattern.compile("(\\b(int|float|double|char|bool|String)\\b)\\s*(\\[\\s*\\d*\\s*\\])+\\s*(\\w*)");
        public ScannerGUI() {
        frame = new JFrame("Java Scanner GUI");
        fileChooser = new JFileChooser();
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.BLACK);

        // Set consistent UI colors
        UIManager.put("TabbedPane.background", Color.DARK_GRAY);
        UIManager.put("TabbedPane.foreground", Color.WHITE);
        UIManager.put("TabbedPane.selected", Color.GRAY);
        UIManager.put("TabbedPane.selectHighlight", Color.GRAY);
        UIManager.put("TabbedPane.contentAreaColor", Color.DARK_GRAY);
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0));
        UIManager.put("TabbedPane.tabsOverlapBorder", true);
        UIManager.put("MenuItem.selectionBackground", Color.GRAY);
        UIManager.put("MenuItem.selectionForeground", Color.WHITE);

        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.BLACK);

        // Input area setup
        inputArea = new JTextPane();
        inputArea.setCaretColor(Color.WHITE);
        inputArea.setBackground(Color.BLACK);
        inputArea.setForeground(Color.WHITE);
        inputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        inputArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { updateStatus(); }
            @Override public void removeUpdate(DocumentEvent e) { updateStatus(); }
            @Override public void changedUpdate(DocumentEvent e) { updateStatus(); }
        });

        JTextArea lineNumbers = createLineNumberComponent(inputArea);
        JScrollPane inputScrollPane = new JScrollPane(inputArea);
        inputScrollPane.setRowHeaderView(lineNumbers);
        inputArea.getDocument().addDocumentListener(new SyntaxHighlighter());

        inputScrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            "Input Code",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Monospaced", Font.PLAIN, 12),
            Color.WHITE
        ));
        inputScrollPane.setBackground(Color.BLACK);

        // Output tabs setup
        outputTabs = new JTabbedPane();
        outputTabs.setBackground(Color.DARK_GRAY);
        outputTabs.setForeground(Color.WHITE);
        createOutputTab("Tokens", "");
        createOutputTab("Symbol Table", "");
        createOutputTab("Syntax Errors", "");
        
        // Create a panel for the output tabs with a minimum size
        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.add(outputTabs, BorderLayout.CENTER);
        outputPanel.setMinimumSize(new Dimension(0, 150));
        
        // Create split pane for resizable output panel
        splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, inputScrollPane, outputPanel);
        splitPane.setResizeWeight(0.7); // Give more space to input area initially
        splitPane.setDividerSize(5);
        splitPane.setOneTouchExpandable(true);
        
        // Add components to main panel
        mainPanel.add(createToolBar(), BorderLayout.NORTH);
        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(createStatusBar(), BorderLayout.SOUTH);

        frame.add(mainPanel);

        // Menu bar setup
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(Color.DARK_GRAY);
        menuBar.setForeground(Color.WHITE);

        JMenu fileMenu = new JMenu("File");
        fileMenu.setForeground(Color.WHITE);
        JMenuItem newItem = new JMenuItem("New");
        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem saveAsItem = new JMenuItem("Save As");

        JMenu aboutMenu = new JMenu("About");
        aboutMenu.setForeground(Color.WHITE);
        JMenuItem aboutItem = new JMenuItem("About this App");

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setForeground(Color.WHITE);
        JMenuItem helpItem = new JMenuItem("Help");

        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.add(saveAsItem);
        aboutMenu.add(aboutItem);
        helpMenu.add(helpItem);

        menuBar.add(fileMenu);
        menuBar.add(aboutMenu);
        menuBar.add(helpMenu);

        frame.setJMenuBar(menuBar);

        // Action listeners
        newItem.addActionListener(e -> inputArea.setText(""));
        openItem.addActionListener(e -> openFile());
        saveItem.addActionListener(e -> saveFile(false));
        saveAsItem.addActionListener(e -> saveFile(true));
        aboutItem.addActionListener(e -> 
            JOptionPane.showMessageDialog(frame, "Java Scanner GUI v1.1"));
        helpItem.addActionListener(e -> showHelp());

        UIManager.put("MenuItem.selectionBackground", Color.GRAY);
        UIManager.put("MenuItem.selectionForeground", Color.WHITE);

        frame.setVisible(true);
    }

    private JToolBar createToolBar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(Color.DARK_GRAY);
        toolBar.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        
        // Create buttons with consistent styling
        JButton newButton = createToolButton("New", "newfile.png");
        JButton openButton = createToolButton("Open", "openfile.png");
        JButton saveButton = createToolButton("Save", "savefile.png");
        JButton scanButton = createToolButton("Scan", "scan.png");
        JButton syntaxButton = createToolButton("CheckSyntax", "syntax.png");

        // Add tooltips
        newButton.setToolTipText("New File");
        openButton.setToolTipText("Open File");
        saveButton.setToolTipText("Save File");
        scanButton.setToolTipText("Scan Code");
        syntaxButton.setToolTipText("Syntax Analysis");

        // Add action listeners
        newButton.addActionListener(e -> inputArea.setText(""));
        openButton.addActionListener(e -> openFile());
        saveButton.addActionListener(e -> saveFile(false));
        scanButton.addActionListener(e -> scanText());
        syntaxButton.addActionListener(e -> analyzeSyntax());

        // Add buttons to toolbar
        toolBar.add(newButton);
        toolBar.add(openButton);
        toolBar.add(saveButton);
        toolBar.addSeparator();
        toolBar.add(scanButton);
        toolBar.add(syntaxButton);

        return toolBar;
    }
    private JButton createToolButton(String text, String iconPath) {
        JButton button = new JButton(text);
        
        // Try to load icon from file, if not found use default icon
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            if (icon.getImage() != null) {
                button.setIcon(icon);
            } else {
                // Use a fallback icon based on the button text
                switch (text) {
                    case "New":
                        button.setIcon(UIManager.getIcon("FileView.fileIcon"));
                        break;
                    case "Open":
                        button.setIcon(UIManager.getIcon("FileView.directoryIcon"));
                        break;
                    case "Save":
                        button.setIcon(UIManager.getIcon("FileView.floppyDriveIcon"));
                        break;
                    case "Scan":
                        button.setIcon(UIManager.getIcon("OptionPane.informationIcon"));
                        break;
                    case "Syntax":
                        button.setIcon(UIManager.getIcon("OptionPane.warningIcon"));
                        break;
                }
            }
        } catch (Exception e) {
            // If icon loading fails, just use text
        }
        
        button.setBackground(Color.DARK_GRAY);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        
        // Add rollover effect using MouseListener instead of setRolloverBackground
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(Color.GRAY);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.DARK_GRAY);
            }
        });
        
        return button;
    }

    private JPanel createStatusBar() {
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBackground(Color.DARK_GRAY);

        statusBar = new JLabel(" Words: 0 | Chars: 0 | Lines: 0 ");
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusBar.setForeground(Color.WHITE);

        statusPanel.add(statusBar, BorderLayout.WEST);
        
        // Add a toggle button to show/hide output panel
        JButton toggleOutput = new JButton("Output");
        toggleOutput.addActionListener(e -> {
            if (splitPane.getBottomComponent().isVisible()) {
                splitPane.setDividerLocation(1.0);
                splitPane.getBottomComponent().setVisible(false);
            } else {
                splitPane.getBottomComponent().setVisible(true);
                splitPane.setDividerLocation(0.7);
            }
            splitPane.revalidate();
        });
        toggleOutput.setBackground(Color.DARK_GRAY);
        toggleOutput.setForeground(Color.WHITE);
        toggleOutput.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusPanel.add(toggleOutput, BorderLayout.EAST);

        return statusPanel;
    }

    private void createOutputTab(String title, String initialContent) {
        JTextArea textArea = new JTextArea(initialContent);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBackground(Color.BLACK);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        outputTabs.addTab(title, scrollPane);
        // Set tab colors
    outputTabs.setBackgroundAt(outputTabs.getTabCount() - 1, Color.DARK_GRAY);
    outputTabs.setForegroundAt(outputTabs.getTabCount() - 1, Color.WHITE);
    }

    private void updateOutputTab(String title, String content, Color textColor) {
        for (int i = 0; i < outputTabs.getTabCount(); i++) {
            if (outputTabs.getTitleAt(i).equals(title)) {
                Component comp = outputTabs.getComponentAt(i);
                if (comp instanceof JScrollPane) {
                    JViewport viewport = ((JScrollPane) comp).getViewport();
                    if (viewport.getView() instanceof JTextArea) {
                        JTextArea textArea = (JTextArea) viewport.getView();
                        textArea.setText(content);
                        textArea.setForeground(textColor);
                        outputTabs.setSelectedIndex(i);
                        // Ensure output panel is visible
                        if (!splitPane.getBottomComponent().isVisible()) {
                            splitPane.getBottomComponent().setVisible(true);
                            splitPane.setDividerLocation(0.7);
                        }
                        return;
                    }
                }
            }
        }
    }

    private void openFile() {
        if (fileChooser == null) {
            fileChooser = new JFileChooser();
        }
        if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            currentFile = fileChooser.getSelectedFile();
            try (Scanner scanner = new Scanner(new FileReader(currentFile))) {
                inputArea.setText("");
                while (scanner.hasNextLine()) {
                    inputArea.setText(inputArea.getText() + scanner.nextLine() + "\n");
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame, "Error opening file", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void saveFile(boolean saveAs) {
        if (fileChooser == null) {
            fileChooser = new JFileChooser();
        }
        if (saveAs || currentFile == null) {
            if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
                currentFile = fileChooser.getSelectedFile();
            } else {
                return;
            }
        }
        try (FileWriter writer = new FileWriter(currentFile)) {
            writer.write(inputArea.getText());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void scanText() {
        String text = inputArea.getText();
        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No text to scan", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        tokens.clear();
        symbolTable.clear();
        processCode(text);
        updateSymbolTable();
        showScanResults();
    }

    private void analyzeSyntax() {
        String text = inputArea.getText();
        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No text to analyze", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<String> errors = checkSyntax(text);
        showSyntaxResults(errors);
    }

    private void showScanResults() {
        // Show tokens
        Map<String, Map<String, Integer>> tokenCounts = new LinkedHashMap<>();
        for (Token token : tokens) {
            String tokenValue = token.value;
            String tokenType = token.type;
            tokenCounts.putIfAbsent(tokenValue, new LinkedHashMap<>());
            tokenCounts.get(tokenValue).put(tokenType, 
                tokenCounts.get(tokenValue).getOrDefault(tokenType, 0) + 1);
        }

        StringBuilder tokenTable = new StringBuilder();
        tokenTable.append(String.format("%-45s %-25s %-10s%n", "Token", "Type", "Count"));
        tokenTable.append("--------------------------------------------------------------------------------\n");
        for (Map.Entry<String, Map<String, Integer>> entry : tokenCounts.entrySet()) {
            String tokenValue = entry.getKey();
            for (Map.Entry<String, Integer> typeEntry : entry.getValue().entrySet()) {
                String tokenType = typeEntry.getKey();
                int count = typeEntry.getValue();
                tokenTable.append(String.format("%-45s %-25s %-10d%n", tokenValue, tokenType, count));
            }
        }
        tokenTable.append("\nTotal Tokens: ").append(tokens.size()).append("\n");
        tokenTable.append("Total Unique Tokens: ").append(tokenCounts.size()).append("\n");
        updateOutputTab("Tokens", tokenTable.toString(), Color.WHITE);

       // Symbol Table tab
    StringBuilder symbolTableText = new StringBuilder();
    symbolTableText.append(String.format("%-15s %-15s %-15s %-10s %-10s %-20s %-10s%n",
        "Name", "Type", "Value", "Size", "Dimension", "Declaration_Line", "Address"));
    
    symbolTableText.append("---------------------------------------------------------------------------------------------------------\n");

    for (SymbolTableEntry entry : symbolTable.values()) {
        symbolTableText.append(String.format("%-15s %-15s %-15s %-10d %-10d %-20d %-10d%n",
            entry.identifier,
            entry.type,
            entry.value != null ? entry.value : "null",  // Display the value
            entry.size,
            entry.dimension,
            entry.declarationLine,
            entry.address));
    }

    updateOutputTab("Symbol Table", symbolTableText.toString(), Color.WHITE);
        // Usage Info tab
        StringBuilder usageText = new StringBuilder();
        usageText.append("Variable Usage Information:\n\n");
        usageText.append(String.format("%-15s %-15s%n", "Variable", "Usage Lines"));
        usageText.append("---------------------------------\n");
        for (SymbolTableEntry entry : symbolTable.values()) {
            usageText.append(String.format("%-15s %-15s%n", 
                entry.identifier,
                entry.usageLines.isEmpty() ? "Unused" : entry.usageLines.toString()));
        }
        updateOutputTab("Usage Info", usageText.toString(), Color.WHITE);
    }
    private void showSyntaxResults(List<String> errors) {
        if (errors.isEmpty()) {
            updateOutputTab("Syntax Errors", "No syntax errors found!", Color.GREEN);
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Syntax Errors Found:\n\n");
            for (String error : errors) {
                sb.append(error).append("\n");
            }
            updateOutputTab("Syntax Errors", sb.toString(), Color.RED);
        }
    }

    private void processCode(String code) {
        String[] lines = code.split("\n");
        boolean inMultiLineComment = false;
        String currentType = null;

        for (int lineNum = 0; lineNum < lines.length; lineNum++) {
            String line = lines[lineNum].trim();
            if (line.isEmpty()) continue;
                // Handle variable declarations with initialization
        if (line.matches(".\\b(int|float|double|char|bool|void)\\b.=.*")) {
            String[] parts = line.split("=");
            String declarationPart = parts[0].trim();
            String valuePart = parts[1].split(";")[0].trim();
            
            // Extract variable name
            String varName = declarationPart.replaceAll(".*\\b(int|float|double|char|bool|void)\\b", "")
                                           .replaceAll("[\\[\\];,]", "")
                                           .trim();
            
            // Update the symbol table with the value
            if (symbolTable.containsKey(varName)) {
                symbolTable.get(varName).value = valuePart;
            }
        }
            // Handle multi-line comments
            if (inMultiLineComment) {
                if (line.contains("*/")) {
                    inMultiLineComment = false;
                    line = line.substring(line.indexOf("*/") + 2).trim();
                } else {
                    continue;
                }
            }

            // Remove single-line comments
            if (line.contains("//")) {
                line = line.substring(0, line.indexOf("//")).trim();
            }

            // Detect multi-line comment start
            if (line.contains("/*")) {
                inMultiLineComment = true;
                line = line.substring(0, line.indexOf("/*")).trim();
            }

            if (line.isEmpty()) continue;
            

            // Handle array declarations first
           
            Matcher arrayMatcher = ARRAY_DECL_PATTERN.matcher(line);
            if (arrayMatcher.find() && DATA_TYPES.contains(arrayMatcher.group(1))) {
                currentType = arrayMatcher.group(1);
                String varPart = arrayMatcher.group(0);
                String[] varParts = varPart.split("\\s+");
                
                for (String part : varParts) {
                    if (part.contains("[")) {
                        // This is an array variable
                        String varName = part.replaceAll("(\\w+).*", "$1");
                        String dimPart = part.substring(varName.length());
                        
                        // Process dimensions
                        Matcher dimMatcher = Pattern.compile("\\[(\\d*)\\]").matcher(dimPart);
                        List<Integer> dimensions = new ArrayList<>();
                        while (dimMatcher.find()) {
                            String dimStr = dimMatcher.group(1);
                            dimensions.add(dimStr.isEmpty() ? 1 : Integer.parseInt(dimStr));
                        }
                        
                        // Calculate size
                        int elementSize = getTypeSize(currentType);
                        int totalSize = elementSize;
                        for (int dim : dimensions) {
                            totalSize *= dim;
                        }
                        
                        // Build type string
                        StringBuilder typeStr = new StringBuilder(currentType);
                        for (int dim : dimensions) {
                            typeStr.append("[").append(dim).append("]");
                        }
                        String initialValue = line.contains("=") ? 
                        line.split("=")[1].split(";")[0].trim() : "null";
                        symbolTable.put(varName, new SymbolTableEntry(
                            varName,
                            typeStr.toString(),
                            initialValue,
                            totalSize,
                            dimensions.size(),
                            lineNum + 1,
                            memoryAddress
                        ));
                        memoryAddress += totalSize;
                        
                        tokens.add(new Token("Identifier", varName, lineNum + 1));
                    }
                }
                continue;
            }

            // Handle regular declarations
            String[] words = line.split("\\s+");
            if (words.length > 0 && DATA_TYPES.contains(words[0])) {
                currentType = words[0];
            }

            List<String> parts = tokenize(line);
            for (String part : parts) {
                if (part.isEmpty()) continue;
                String initialValue = line.contains("=") ? line.split("=")[1].split(";")[0].trim() : "null";

                if (KEYWORDS.contains(part)) {
                    tokens.add(new Token("Keyword", part, lineNum + 1));
                    currentType = part;
                } else if (OPERATORS.contains(part)) {
                    tokens.add(new Token("Operator", part, lineNum + 1));
                } else if (SEPARATORS.contains(part)) {
                    tokens.add(new Token("Separator", part, lineNum + 1));
                }else if (part.equals("true") || part.equals("false")) {
                    tokens.add(new Token("Literal (Boolean)", part, lineNum + 1));
                }
                 else if (part.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
                    tokens.add(new Token("Identifier", part, lineNum + 1));
                    if (currentType != null && !symbolTable.containsKey(part)) {
                        symbolTable.put(part, new SymbolTableEntry(
                            part,
                            currentType,
                            initialValue, 
                            getTypeSize(currentType),
                            0, // Scalar
                            lineNum + 1,
                            memoryAddress
                        ));
                        memoryAddress += getTypeSize(currentType);
                    }
                } else if (part.matches("\\d+")) {
                    tokens.add(new Token("Literal (Int)", part, lineNum + 1));
                } else if (part.matches("\\d+\\.\\d+([eE][+-]?\\d+)?")) {
                    tokens.add(new Token("Literal (Float)", part, lineNum + 1));
                } else if (part.startsWith("\"") && part.endsWith("\"")) {
                    tokens.add(new Token("Literal (String)", part, lineNum + 1));
                } else if (part.startsWith("'") && part.endsWith("'")) {
                    tokens.add(new Token("Literal (Char)", part, lineNum + 1));
                } else {
                    tokens.add(new Token("Unknown", part, lineNum + 1));
                }
            }
        }
    }

    private int getTypeSize(String type) {
        if (type.contains("[")) {
            type = type.substring(0, type.indexOf("["));
        }
        switch (type) {
            case "boolean": return 1;
            case "char": return 1;
            case "int": return 4;
            case "float": return 4;
            case "double": return 8;
            case "String": return 24;
            default: return 4;
        }
    }
    private boolean isFunctionDeclaration(String line) {
        return line.matches(".*\\b[a-zA-Z_][a-zA-Z0-9_]*\\s*\\(.*\\)\\s*\\{?");
       }
       
   private boolean hasMainFunction(String code) {
    // Remove comments first to avoid false positives
    String cleanedCode = code.replaceAll("/\\.?\\/", "").replaceAll("//.", "");
    
    // More robust main function detection
    Pattern mainPattern = Pattern.compile(
        "\\bint\\s+main\\s*\\(\\s*(void)?\\s*\\)\\s*\\{",
        Pattern.MULTILINE);
    return mainPattern.matcher(cleanedCode).find();
}
private int getMainStartLine(String[] lines) {
     Pattern mainPattern = Pattern.compile("\\bint\\s+main\\s*\\(.*\\)\\s*\\{?");
     for (int i = 0; i < lines.length; i++) {
     if (mainPattern.matcher(lines[i].trim()).find()) {
     return i;
    }
   }
    return -1;
    }
    
    private List<String> checkSyntax(String code) {
        List<String> errors = new ArrayList<>();
        String[] lines = code.split("\n");
        // Track main() body braces
        int mainStartLine = getMainStartLine(lines);
        int mainBraceBalance = 0;
        boolean insideMain = false;
        Stack<Integer> braceStack = new Stack<>();
        Stack<Integer> parenStack = new Stack<>();
        boolean inMultiLineComment = false;
        boolean inRawString = false;
        Map<String, String> declaredVariables = new HashMap<>();
        Map<String, Boolean> isConstant = new HashMap<>();
        Map<String, Boolean> isInitialized = new HashMap<>();
        // Track if-else nesting
   
        // Add this at the start of the method
        int commentStartLine = -1;
        if (!hasMainFunction(code)) {
            errors.add("Error: Missing main function 'int main()'");
        }
        Set<String> reservedKeywords = new HashSet<>(Arrays.asList(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
            "class", "const", "continue", "default", "do", "double", "else", "enum",
            "extends", "final", "finally", "float", "for", "goto", "if", "implements",
            "import", "instanceof", "int", "interface", "long", "native", "new", "package",
            "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient",
            "try", "void", "volatile", "while", "true", "false", "null"
        ));
    
        for (int lineNum = 0; lineNum < lines.length; lineNum++) {
            String line = lines[lineNum].trim();
            if (line.isEmpty()) continue;
            if (lineNum == mainStartLine) {
                insideMain = true;
                }
                
                if (insideMain) {
                 for (char ch : line.toCharArray()) {
                if (ch == '{') mainBraceBalance++;
                else if (ch == '}') mainBraceBalance--;
                }
                
                if (mainBraceBalance == 0 && lineNum > mainStartLine) {
               insideMain = false;
              }
                }
                 // 1. Check for variable declarations without data types (e.g., "a;")
        if (line.matches("^[a-zA-Z_]\\w*\\s*;\\s*$") && 
        !KEYWORDS.contains(line.replace(";", "").trim()) &&
        !OPERATORS.contains(line.replace(";", "").trim()) &&
        !SEPARATORS.contains(line.replace(";", "").trim())) {
        String varName = line.replace(";", "").trim();
        errors.add("Line " + (lineNum + 1) + ": Missing data type in variable declaration '" + varName + "'");
    }

    // 2. Check for standalone expressions (e.g., "a+b;")
    if (line.matches(".*[+\\-*/%].*;") && 
        !line.matches(".*\\b(int|float|double|char|bool|String)\\b.*") &&
        !line.contains("=") && 
        !line.matches(".*\\b(if|while|for|return)\\b.*")) {
        errors.add("Line " + (lineNum + 1) + ": Standalone expression without assignment or statement context '" + line + "'");
    }
    // 3. Check for incorrect initialization syntax (e.g., "int a # 5;")
    if (line.matches(".*\\b(int|float|double|char|bool|String)\\b.*") && 
    line.contains(";") && 
    !line.matches(".*\\b(int|float|double|char|bool|String)\\b\\s+\\w+\\s*(=\\s*[^;]+)?\\s*;.*")) {
    errors.add("Line " + (lineNum + 1) + ": Incorrect initialization syntax. Expected format: 'type variableName [= value];'");
}
                // Replace your current operand checks with this improved version
if (line.matches(".*\\b(if|while|for)\\s*\\(.*")) {
    // Extract the condition part
    String condition = line.replaceAll(".*\\b(if|while|for)\\s*\\((.*)\\).*", "$2").trim();
    
    // Check for operators without both operands
    String[] operators = {"<", ">", "<=", ">=", "==", "!="};
    for (String op : operators) {
        if (condition.contains(op)) {
            String[] parts = condition.split(Pattern.quote(op));
            
            // Check left operand
            if (parts[0].trim().isEmpty()) {
                errors.add("Line " + (lineNum + 1) + 
                    ": Missing left operand for operator '" + op + "'");
            }
            
            // Check right operand
            if (parts.length < 2 || parts[1].trim().isEmpty()) {
                errors.add("Line " + (lineNum + 1) + 
                    ": Missing right operand for operator '" + op + "'");
            }
        }
    }
    
    // Check for standalone operators
    if (condition.matches(".*[<>=!]=?\\s*[;)].*")) {
        errors.add("Line " + (lineNum + 1) + 
            ": Incomplete comparison - missing operand");
    }
}

              // Check for self-referential initialization (e.g., int a = a;)
if (hasSelfReference(line)) {
    errors.add("Line " + (lineNum + 1) + ": Self-referential initialization detected");
}

// Enhanced for loop checking
if (line.trim().startsWith("for")) {
    if (!line.contains("(") || !line.contains(")")) {
        errors.add("Line " + (lineNum + 1) + ": For loop requires parentheses");
    } else {
        String forParts = line.replaceAll(".*for\\s*\\((.*)\\).*", "$1");
        String[] parts = forParts.split(";");
        
        if (parts.length != 3) {
            errors.add("Line " + (lineNum + 1) + ": For loop requires three parts separated by semicolons");
        } else {
            // Check initialization part
            if (!parts[0].trim().isEmpty() && 
                !parts[0].matches("\\s*((int\\s+)?[a-zA-Z_]\\w*\\s*=\\s*.+)?\\s*")) {
                errors.add("Line " + (lineNum + 1) + ": Invalid for loop initialization: " + parts[0]);
            }
            
            // Check condition part
            if (parts[1].trim().isEmpty()) {
                errors.add("Line " + (lineNum + 1) + ": For loop requires a condition");
            } else if (!parts[1].matches("\\s*([a-zA-Z_]\\w*\\s*([<>=!]=?)\\s*.+)?\\s*")) {
                errors.add("Line " + (lineNum + 1) + ": Invalid for loop condition: " + parts[1]);
            }
            
            // Check increment part
            if (!parts[2].trim().isEmpty() && 
                !parts[2].matches("\\s*([a-zA-Z_]\\w*\\s*(\\+\\+|--|=[^=]|[-+*/%]=).*)?\\s*")) {
                errors.add("Line " + (lineNum + 1) + ": Invalid for loop increment: " + parts[2]);
            }
        }
    }
}


// Enhanced while loop checking
if (line.trim().startsWith("while")) {
    if (!line.contains("(") || !line.contains(")")) {
        errors.add("Line " + (lineNum + 1) + ": While loop requires parentheses");
    } else {
        String condition = line.replaceAll(".*while\\s*\\((.*)\\).*", "$1").trim();
        if (condition.isEmpty()) {
            errors.add("Line " + (lineNum + 1) + ": While loop requires a condition");
        } else if (!condition.matches(".+([<>=!]=?).+")) {
            errors.add("Line " + (lineNum + 1) + ": Invalid while loop condition: " + condition);
        }
    }
}
 // Enhanced expression checking
 if (line.contains("=") && !line.startsWith("//") && !line.contains("==") && !line.contains("!=")) {
    String[] assignmentParts = line.split("=");
    if (assignmentParts.length >= 2) {
        String rhs = assignmentParts[1].split(";")[0].trim();
        // Check for invalid operators at start/end
        if (hasInvalidOperatorAtStartOrEnd(rhs)) {
            errors.add("Line " + (lineNum + 1) + ": Invalid operator at start or end of expression");
        }
        
        // Check for invalid operator combinations
        if (hasInvalidOperatorCombination(rhs)) {
            errors.add("Line " + (lineNum + 1) + ": Invalid operator combination in expression");
        }
        
        
    }
}
// Check return statements
if (line.trim().startsWith("return") && line.contains(";")) {
    String returnExpr = line.replaceAll("return\\s*(.*);", "$1").trim();
    if (!returnExpr.isEmpty()) {
        if (hasInvalidOperatorAtStartOrEnd(returnExpr)) {
            errors.add("Line " + (lineNum + 1) + ": Invalid operator at start or end of return expression");
        }
        if (hasInvalidOperatorCombination(returnExpr)) {
            errors.add("Line " + (lineNum + 1) + ": Invalid operator combination in return expression");
        }
    }
}

            // Check for lines starting with invalid characters
        if (startsWithInvalidCharacter(line)) {
            errors.add("Line " + (lineNum + 1) + ": Line starts with invalid character");
        }
        
        
    
             // Check for unterminated raw string from previous line
        if (inRawString) {
            if (!line.contains("\")")) {
                errors.add("Line " + (lineNum + 1) + ": Unterminated raw string literal");
                continue;
            } else {
                inRawString = false;
            }
        }
        // Check for raw strings
        if (line.contains("R\"(") && !line.contains("\")")) {
            inRawString = true;
            errors.add("Line " + (lineNum + 1) + ": Unterminated raw string literal");
        }
        // Check for unterminated multi-line comment
        if (inMultiLineComment) {
            if (line.contains("*/")) {
                inMultiLineComment = false;
                line = line.substring(line.indexOf("*/") + 2).trim();
            } else {
                continue; // Skip processing until we find the end of comment
            }
        } else if (line.contains("/*")) {
            if (!line.contains("*/")) {
                inMultiLineComment = true;
                commentStartLine = lineNum + 1;
            }
            line = line.substring(0, line.indexOf("/*")).trim();
        }
        // Check for double semicolons
        if (line.contains(";;")) {
            errors.add("Line " + (lineNum + 1) + ": Double semicolon detected");
        }
        //Check for invalid boolean literals
        if (line.matches(".\\bboolean\\b.=.(true|false|TRUE|FALSE).")) {
            String valuePart = line.split("=")[1].split(";")[0].trim();
            if (!valuePart.equals("true") && !valuePart.equals("false") && 
                !valuePart.equals("TRUE") && !valuePart.equals("FALSE")) {
                errors.add("Line " + (lineNum + 1) + ": Invalid boolean literal - must be 'true' or 'false'");
            } else if (valuePart.equals("TRUE") || valuePart.equals("FALSE")) {
                errors.add("Line " + (lineNum + 1) + ": Boolean literals must be lowercase - use 'true' or 'false'");
            }
        }
         // Check for string literals with single quotes
         if (line.matches(".\\bString\\b.=.'.'.*")) {
            errors.add("Line " + (lineNum + 1) + ": String literals must use double quotes, not single quotes");
        }


            if (inMultiLineComment) {
                if (line.contains("*/")) {
                    inMultiLineComment = false;
                    line = line.substring(line.indexOf("*/") + 2).trim();
                } else {
                    continue;
                }
            }
    
            if (line.contains("//")) {
                line = line.substring(0, line.indexOf("//")).trim();
            }
    
            if (line.contains("/*")) {
                inMultiLineComment = true;
                line = line.substring(0, line.indexOf("/*")).trim();
            }
            if (line.contains("=") || line.matches(".*(\\+\\+|\\-\\-).*")) {
                String exprLine = line.replaceAll("\\s+", "");
            
                if (line.contains("=") && !line.startsWith("//") && !line.contains("==") && 
    !line.contains("!=") && !line.trim().startsWith("if") && 
    !line.trim().startsWith("else") && !line.trim().startsWith("for") && 
    !line.trim().startsWith("while")) {
                    String[] parts = exprLine.split("=");
                    if (parts.length > 2 && !line.trim().startsWith("if") && 
                    !line.trim().startsWith("else") && !line.trim().startsWith("for") && 
                    !line.trim().startsWith("while")) {
                    errors.add("Line " + (lineNum + 1) + ": Chained assignment is not allowed.");
                }
                    if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty()) {
                        errors.add("Line " + (lineNum + 1) + ": Invalid assignment syntax.");
                        return errors;
                    }
            
                    String lhs = parts[0];
                    String rhs = parts[1];
            
                    
            
                    if (!rhs.endsWith(";")) {
                        errors.add("Line " + (lineNum + 1) + ": Missing semicolon at end of statement.");
                    } else {
                        rhs = rhs.substring(0, rhs.length() - 1);
                    }
            
                    if (rhs.isEmpty() || rhs.matches("^[\\+\\-\\*/%]$")) {
                        errors.add("Line " + (lineNum + 1) + ": Assignment has invalid start of expression after '='.");
                        return errors;
                    }
            
                    // (1) Division by zero - literal and simple constant expression
                    if (rhs.matches(".*\\/0(?![0-9]).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Division by zero (literal).");
                    }
                    if (rhs.matches(".*\\/\\(\\s*\\d+\\s*[-+]\\s*\\d+\\s*\\).*")) {
                        String inside = rhs.replaceAll(".*\\/\\((\\d+)\\s*([-+])\\s*(\\d+)\\).*", "$1$2$3");
                        try {
                            int result = Integer.parseInt(inside.replace("+", "")); // simple eval
                            if (result == 0) {
                                errors.add("Line " + (lineNum + 1) + ": Division by zero (constant expression).");
                            }
                        } catch (Exception ignored) {}
                    }
            
                    // (2) Invalid operand types
                    if (rhs.matches(".*[\\+\\-\\*/%]\\s*\".*\".*") || rhs.matches(".*\".*\"\\s*[\\+\\-\\*/%].*")) {
                        errors.add("Line " + (lineNum + 1) + ": Cannot apply arithmetic operator to a string.");
                    }
                    if (rhs.matches(".*[\\+\\-\\*/%]\\s*(true|false).*") || rhs.matches(".*(true|false)\\s*[\\+\\-\\*/%].*")) {
                        errors.add("Line " + (lineNum + 1) + ": Cannot use boolean in arithmetic operation.");
                    }
            
                    // (3) Ambiguous precedence
                    if (rhs.matches(".*[&|^][\\+\\-\\*/%].*") || rhs.matches(".*[\\+\\-\\*/%][&|^].*")) {
                        errors.add("Line " + (lineNum + 1) + ": Suspicious operator precedence between bitwise and arithmetic.");
                    }
            
                    // (4) Missing operands inside parentheses (e.g., (5 + ), (-), etc.)
                    if (rhs.matches(".*\\([\\+\\-\\*/%]\\).*") ||
                        rhs.matches(".*[\\+\\-\\*/%]\\).*") || rhs.matches(".*\\([\\+\\-\\*/%].*\\).*") && rhs.matches(".*\\([\\+\\-\\*/%]\\).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Missing operand inside parentheses.");
                    }
            
                    // (4b) Invalid leading operator before expression in parentheses (e.g., +(...))
                    if (rhs.matches("^[\\+\\-\\*/%]\\(.*\\).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Invalid leading operator before parenthesized expression.");
                    }
            
                    // (5) Increment/Decrement misuse
                    
                    if (rhs.matches(".*(\\+\\+|\\-\\-)[^a-zA-Z_\\(].*") || rhs.matches(".*[^a-zA-Z0-9_\\)](\\+\\+|\\-\\-).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Misuse of increment/decrement operator.");
                    }
                    if (rhs.matches(".*(\\+\\+\\-\\-|\\-\\-\\+\\+).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Invalid stacked increment/decrement operators.");
                    }
                    if (rhs.matches(".*(\\+\\+|\\-\\-)\\(.*\\).*")) {
                        errors.add("Line " + (lineNum + 1) + ": Cannot apply increment/decrement to an expression.");
                    }
            
                    // Token scan for consecutive operators and number-variable merging
                    String[] tokens = rhs.split("(?<=[\\+\\-\\*/%])|(?=[\\+\\-\\*/%])");
                    String prev = "";
                    for (String token : tokens) {
                        if (token.isEmpty()) continue;
            
                        if (prev.matches("[+\\-*/%]") && token.matches("[+\\-*/%]") && 
                        !prev.matches("[+\\-]") && !token.matches("[+\\-]")) {
                        // Allow cases like "x = -5" or "y = +3"
                        errors.add("Line " + (lineNum + 1) + ": Consecutive operators '" + prev + token + "' are invalid");
                        break;
                    }
            
                        if (token.matches(".*\\d+[a-zA-Z_]+.*")) {
                            errors.add("Line " + (lineNum + 1) + ": Missing operator between number and variable.");
                            break;
                        }
            
                        prev = token;
                    }
                }
            
                // Standalone ++x; or x--
                else if (exprLine.matches("^(\\+\\+|\\-\\-)[a-zA-Z_][a-zA-Z0-9_]*;$") ||
                         exprLine.matches("^[a-zA-Z_][a-zA-Z0-9_]*(\\+\\+|\\-\\-);$")) {
                    // Valid
                } else if (exprLine.matches("^(\\+\\+|\\-\\-)[0-9]+;$") ||
                           exprLine.matches("^[0-9]+(\\+\\+|\\-\\-);$")) {
                    errors.add("Line " + (lineNum + 1) + ": Cannot increment/decrement a literal.");
                } else if (line.contains("=") && !line.startsWith("//") && !line.contains("==") && 
                !line.contains("!=") && !line.trim().startsWith("if") && 
                !line.trim().startsWith("else") && !line.trim().startsWith("for") && 
                !line.trim().startsWith("while") && !line.trim().startsWith("return")){
                    errors.add("Line " + (lineNum + 1) + ": Invalid arithmetic expression.");
                }
            }
            
            if (line.isEmpty()) continue;
    
            for (int i = 0; i < line.length(); i++) {
                char c = line.charAt(i);
                if (c == '{') braceStack.push(lineNum + 1);
                else if (c == '}') {
                    if (braceStack.isEmpty()) errors.add("Line " + (lineNum + 1) + ": Unmatched '}'");
                    else braceStack.pop();
                } else if (c == '(') parenStack.push(lineNum + 1);
                else if (c == ')') {
                    if (parenStack.isEmpty()) errors.add("Line " + (lineNum + 1) + ": Unmatched ')'");
                    else parenStack.pop();
                }
            }
    
            for (String type : DATA_TYPES) {
                if (line.startsWith(type + " ")) {
                    if (isFunctionDeclaration(line)) {
                         break; // skip further checks
                     }
                    String declarationAfterType = line.substring(type.length()).trim();
                    if (declarationAfterType.isEmpty() || declarationAfterType.equals(";")) {
                        errors.add("Line " + (lineNum + 1) + ": Incomplete variable declaration after '" + type + "'");
                        continue;
                    }
    
                    for (String otherType : DATA_TYPES) {
                        if (!otherType.equals(type) && line.contains(otherType + " ")) {
                            errors.add("Line " + (lineNum + 1) + ": Multiple data types in one declaration");
                            break;
                        }
                    }
    
                    String rest = line.substring(type.length()).trim();
                    String[] declarations = rest.split(",");
                    for (String decl : declarations) {
                        decl = decl.trim().split(";")[0];
                        String varName = decl.split("[=\\s\\[]")[0].trim();
    
                        int equalsCount = decl.length() - decl.replace("=", "").length();
                        if (equalsCount > 1) {
                            errors.add("Line " + (lineNum + 1) + ": Extra equals sign(s) in initialization near '" + decl.trim() + "'");
                        }
    
                        String[] declParts = decl.trim().split("\\s+");
                        if (!decl.contains("=") && declParts.length >= 2) {
                            String possibleValue = declParts[declParts.length - 1];
                            if (!possibleValue.equals(";") && possibleValue.matches("[a-zA-Z0-9_\"']+")) {
                                errors.add("Line " + (lineNum + 1) + ": Missing equals sign '=' in initialization near '" + decl + "'");
                            }
                        }
    
                        // Replace the current variable name check with:
                            if (!varName.isEmpty() && !varName.matches("^[a-zA-Z_][a-zA-Z0-9_]*$")) {
                                errors.add("Line " + (lineNum + 1) + ": Invalid variable name '" + varName + 
                                        "'. Must start with letter or underscore and contain only alphanumeric characters and underscores");
                            }
    
                        if (reservedKeywords.contains(varName)) {
                            errors.add("Line " + (lineNum + 1) + ": Reserved keyword used as variable name '" + varName + "'");
                            continue;
                        }
    
                        if (declaredVariables.containsKey(varName)) {
                            errors.add("Line " + (lineNum + 1) + ": Redeclaration of variable '" + varName + "'");
                        } else {
                            declaredVariables.put(varName, type);
                            isInitialized.put(varName, decl.contains("="));
                            if (line.contains("const")) {
                                isConstant.put(varName, true);
                            }
                        }
    
                        if (decl.contains("=")) {
                            String value = decl.split("=")[1].trim().split(";")[0].trim();
                            if (symbolTable.containsKey(varName)) {
                                symbolTable.get(varName).value = value;
                            }
                          // Enhanced type checking that uses your existing methods
switch (type) {
    case "int":
        if (!value.matches("-?\\d+") && 
            !declaredVariables.containsKey(value) &&
            !value.matches(".*[-+*/%].*")) {  // Allow simple arithmetic
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected int but got '" + value + "'");
        } else if (declaredVariables.containsKey(value)) {
            String varType = declaredVariables.get(value);
            if (!varType.equals("int") && !varType.equals("float") && !varType.equals("double")) {
                errors.add("Line " + (lineNum + 1) + ": Cannot assign " + varType + " to int");
            }
        }
        break;
        
    case "float":
        if (!value.matches("-?\\d+\\.?\\d*f?") && 
            !declaredVariables.containsKey(value) &&
            !value.matches(".*[-+*/%].*")) {  // Allow simple arithmetic
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected float but got '" + value + "'");
        } else if (declaredVariables.containsKey(value)) {
            String varType = declaredVariables.get(value);
            if (!varType.equals("int") && !varType.equals("float") && !varType.equals("double")) {
                errors.add("Line " + (lineNum + 1) + ": Cannot assign " + varType + " to float");
            }
        }
        break;
        
    case "double":
        if (!value.matches("-?\\d+\\.?\\d*") && 
            !declaredVariables.containsKey(value) &&
            !value.matches(".*[-+*/%].*")) {  // Allow simple arithmetic
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected double but got '" + value + "'");
        } else if (declaredVariables.containsKey(value)) {
            String varType = declaredVariables.get(value);
            if (!varType.equals("int") && !varType.equals("float") && !varType.equals("double")) {
                errors.add("Line " + (lineNum + 1) + ": Cannot assign " + varType + " to double");
            }
        }
        break;
        
    case "char":
        if (!value.matches("'.'") && 
            !value.matches("'\\\\[nrt0]'") &&  // Using your escape sequence pattern
            !declaredVariables.containsKey(value)) {
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected char but got '" + value + "'");
        } else if (declaredVariables.containsKey(value) && !declaredVariables.get(value).equals("char")) {
            errors.add("Line " + (lineNum + 1) + ": Cannot assign " + declaredVariables.get(value) + " to char");
        }
        break;
        
    case "bool":
        // Using your isInvalidBooleanLiteral method
        if (isInvalidBooleanLiteral(value) && !declaredVariables.containsKey(value)) {
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected boolean (true/false) but got '" + value + "'");
        } else if (declaredVariables.containsKey(value) && !declaredVariables.get(value).equals("bool")) {
            errors.add("Line " + (lineNum + 1) + ": Cannot assign " + declaredVariables.get(value) + " to boolean");
        }
        break;
        
    case "String":
        // Using your hasInvalidStringLiteral method for the line
        if (hasInvalidStringLiteral(line)) {
            errors.add("Line " + (lineNum + 1) + ": String literals must use double quotes");
        } else if (!value.matches("\".*\"") && !declaredVariables.containsKey(value)) {
            errors.add("Line " + (lineNum + 1) + ": Type mismatch - expected String but got '" + value + "'");
        } else if (declaredVariables.containsKey(value) && !declaredVariables.get(value).equals("String")) {
            errors.add("Line " + (lineNum + 1) + ": Cannot assign " + declaredVariables.get(value) + " to String");
        }
        break;
}
                    }
                }
      
                    if (!line.endsWith(";") && !line.endsWith("{")) {
                        errors.add("Line " + (lineNum + 1) + ": Missing semicolon after declaration");
                    }
                }
            }
    
            if (line.matches("[a-zA-Z_][a-zA-Z0-9_]\\s;") && !reservedKeywords.contains(line.split("\\s+")[0])) {
                errors.add("Line " + (lineNum + 1) + ": Missing data type for variable '" + line + "'");
            }
    
            String cleanedLine = line.replaceAll("[^a-zA-Z0-9_]", " ");
            String[] tokens = cleanedLine.split("\\s+");
            for (String token : tokens) {
                if (declaredVariables.containsKey(token)) {
                    if (!isInitialized.getOrDefault(token, false) &&
                            !line.matches(".\\b" + token + "\\s=.*")) {
                        errors.add("Line " + (lineNum + 1) + ": Use of uninitialized variable '" + token + "'");
                    }
                }
            }
    
            if (line.contains("=") && !line.startsWith("//") && !line.contains("==") && !line.contains("!=")) {
                String[] assignmentParts = line.split("=");
                if (assignmentParts.length >= 2) {
                    String lhs = assignmentParts[0].trim();
                    lhs = lhs.replaceAll("\\[.?\\]", "").replaceAll("\\(.?\\)", "");
    
                    if (lhs.matches("\\d+(\\.\\d+)?") ||
                        lhs.matches("'[^']'|\"[^\"]\"|true|false|null")) {
                        errors.add("Line " + (lineNum + 1) + ": Invalid assignment target '" + lhs + "'");
                    } else {
                        if (!declaredVariables.containsKey(lhs) && lhs.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
                            errors.add("Line " + (lineNum + 1) + ": Undeclared variable '" + lhs + "'");
                        } 
                    }
                }
            }
    
            if (line.contains("if") || line.contains("else") || line.contains("for") || line.contains("while")) {
                // 1. Missing parentheses for 'if'
                if (line.matches(".*\\bif\\b\\s+[^\\(\\s].*")) {
                    errors.add("Line " + (lineNum + 1) + ": Missing '(' after 'if'");
                }          
            // 2. Missing braces for multi-line 'if'
            // Detect 'if (condition)' with no braces followed by more than 1 non-empty line
            if (line.matches("^\\s*if\\s*\\(.*\\)\\s*$")) {
                int nonEmptyLines = 0;
                for (int j = lineNum + 1; j < Math.min(lineNum + 3, lines.length); j++) {
                    String next = lines[j].trim();
                    if (!next.isEmpty() && !next.startsWith("//")) nonEmptyLines++;
                }
                if (nonEmptyLines > 1) {
                    errors.add("Line " + (lineNum + 1) + ": Missing braces '{ }' for multi-line if body");
                }
            }
            // 3. Dangling 'else' without matching 'if'
            // Replace your current else checking with:
if (line.matches("^\\s*else\\b.*")) {
    boolean hasMatchingIf = false;
    // Look backwards for matching if
    for (int j = lineNum - 1; j >= 0; j--) {
        String prevLine = lines[j].trim();
        if (prevLine.isEmpty() || prevLine.startsWith("//")) continue;
        
        if (prevLine.matches(".*\\bif\\b.*") || 
            prevLine.matches(".*\\belse\\s+if\\b.*")) {
            hasMatchingIf = true;
            break;
        } else if (prevLine.startsWith("}")) {
            // Skip past the closing brace
        } else {
            break;
        }
    }
    
    if (!hasMatchingIf) {
        errors.add("Line " + (lineNum + 1) + ": 'else' without a matching 'if'");
    }
}
            
            // 5. Assignment '=' used instead of comparison '=='
            if (line.matches(".*\\bif\\s*\\(.*[^=!<>]=[^=].*\\).*")) {
                errors.add("Line " + (lineNum + 1) + ": Assignment '=' used instead of comparison '==' in 'if' condition?");
            }
            // Check for incomplete expressions in if conditions
if (line.matches(".*if\\s*\\(.*[+\\-*/%]\\s*\\).*")) {
    errors.add("Line " + (lineNum + 1) + ": Incomplete expression in if condition - missing operand");
}
            // 6. Empty 'if' condition
            if (line.matches(".*\\bif\\s*\\(\\s*\\)\\s*\\{?.*")) {
                errors.add("Line " + (lineNum + 1) + ": Empty condition in 'if' statement");
            }
            // 7.Detect nested 'if' statements without braces
            if (line.matches(".*\\bif\\b.*") && !line.contains("{") && lineNum + 1 < lines.length) {
                String nextLine = lines[lineNum + 1].trim();
                if (nextLine.matches(".*\\bif\\b.*") && !nextLine.contains("{")) {
                    errors.add("Line " + (lineNum + 1) + ": Nested 'if' statements should use braces '{ }'");
                }
            }
            // 8.Detect 'else' following 'return' in a function body
            if (line.matches("^\\s*else\\b.*") && lineNum > 0) {
                String prevLine = lines[lineNum - 1].trim();
                if (prevLine.matches(".*\\breturn\\b.*")) {
                    errors.add("Line " + (lineNum + 1) + ": 'else' cannot follow 'return' statement");
                }
            }
            
                if (line.contains("(") && !line.contains(")")) {
                    errors.add("Line " + (lineNum + 1) + ": Missing closing parenthesis ')'");
                } else if (line.contains(")") && !line.contains("(")) {
                    errors.add("Line " + (lineNum + 1) + ": Missing opening parenthesis '('");
                }
    
                
            }
    
            if (!line.endsWith(";") && !line.endsWith("{") && !line.endsWith("}") &&
            !line.trim().startsWith("if") && !line.trim().startsWith("else") && 
            !line.trim().startsWith("for") && !line.trim().startsWith("while") && 
            !line.trim().startsWith("return") && !line.isEmpty() &&
            !line.startsWith("#") && !line.trim().startsWith("//")) {
            errors.add("Line " + (lineNum + 1) + ": Missing semicolon");
        }
        }
    
        while (!braceStack.isEmpty()) {
            errors.add("Line " + braceStack.pop() + ": Unmatched '{'");
        }
    
        while (!parenStack.isEmpty()) {
            errors.add("Line " + parenStack.pop() + ": Unmatched '('");
        }
    // Check for unterminated multi-line comment at end of file
    if (inMultiLineComment) {
        errors.add("Line " + commentStartLine + ": Unterminated multi-line comment");
    }
    if (mainStartLine != -1 && mainBraceBalance != 0) {
         errors.add("Error: Missing closing brace '}' for main() function starting at line " + (mainStartLine + 1));
        }
        
        return errors;
    }
    private boolean hasInvalidOperatorAtStartOrEnd(String expr) {
        // Check for operators at start or end (excluding unary +- and ++ --)
        if (expr.matches("^\\s*[*/%=+\\-](?![+\\-]).*") ||  // Operator at start (not ++ or --)
            expr.matches(".*[*/%+\\-](?![+\\-])\\s*$")) {   // Operator at end (not ++ or --)
            return true;
        }
        return false;
    }
    
    private boolean hasInvalidOperatorCombination(String expr) {
        // Check for invalid operator combinations like a+_+, 5+-, +_5
        Pattern invalidCombo = Pattern.compile("([+\\-*/%]\\s*[^\\w\\s(])|([^\\w\\s)]\\s*[+\\-*/%])");
        return invalidCombo.matcher(expr).find();
    }
    
    private boolean hasSelfReference(String line) {
        // Check for patterns like "int a = a;"
        if (line.contains("=")) {
            String[] parts = line.split("=");
            if (parts.length >= 2) {
                String lhs = parts[0].replaceAll(".*\\b(int|float|double|char|bool|String)\\b", "")
                                    .replaceAll("[\\[\\];,]", "")
                                    .trim();
                String rhs = parts[1].split(";")[0].trim();
                return lhs.equals(rhs);
            }
        }
        return false;
    }
    private boolean startsWithInvalidCharacter(String line) {
        if (line.trim().isEmpty()) return false;
        char firstChar = line.trim().charAt(0);
        return !Character.isLetter(firstChar) && 
               firstChar != '_' && 
               firstChar != '/' &&  // allow comments
               firstChar != '#' &&  // allow preprocessor directives
               firstChar != '{' &&  // allow code blocks
               firstChar != '}';
    }
    
    
    private boolean isInvalidBooleanLiteral(String value) {
        return value.matches(".[tT][rR][uU][eE].") || 
               value.matches(".[fF][aA][lL][sS][eE].") ||
               !(value.equals("true") || value.equals("false"));
    }
    
    private boolean hasInvalidStringLiteral(String line) {
        // Check for single-quoted strings where double quotes are expected
        return line.matches(".\\bString\\b.=.'.'.*") ||
               line.matches(".\\bstring\\b.=.'.'.*");
    }
    private List<String> tokenize(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder buffer = new StringBuilder();
        boolean inString = false;
        boolean inChar = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '\"' || ch == '"' || ch == '\"') {
                if (inString) {
                    buffer.append('\"');
                    result.add(buffer.toString());
                    buffer.setLength(0);
                    inString = false;
                } else {
                    if (buffer.length() > 0) {
                        result.add(buffer.toString());
                        buffer.setLength(0);
                    }
                    buffer.append('\"');
                    inString = true;
                }
                continue;
            }
            if (ch == '\'' && !inString) {
                if (inChar) {
                    buffer.append(ch);
                    result.add(buffer.toString());
                    buffer.setLength(0);
                    inChar = false;
                } else {
                    if (buffer.length() > 0) {
                        result.add(buffer.toString());
                        buffer.setLength(0);
                    }
                    buffer.append(ch);
                    inChar = true;
                }
                continue;
            }
            // Check for compound operators (++ and --)
if (!inString && !inChar) {
    if (i + 1 < line.length()) {
        String twoCharOp = "" + line.charAt(i) + line.charAt(i + 1);
        if (OPERATORS.contains(twoCharOp)) {
            if (buffer.length() > 0) {
                result.add(buffer.toString());
                buffer.setLength(0);
            }
            result.add(twoCharOp);
            i++; // skip next character too
            continue;
        }
    }

    String oneChar = String.valueOf(ch);
    if (SEPARATORS.contains(oneChar) || OPERATORS.contains(oneChar)) {
        if (buffer.length() > 0) {
            result.add(buffer.toString());
            buffer.setLength(0);
        }
        result.add(oneChar);
    } else if (Character.isWhitespace(ch)) {
        if (buffer.length() > 0) {
            result.add(buffer.toString());
            buffer.setLength(0);
        }
    } else {
        buffer.append(ch);
    }
} else {
    buffer.append(ch);
}
        }
        if (buffer.length() > 0) {
            result.add(buffer.toString());
        }

        return result;
    }

    private void updateSymbolTable() {
        Map<String, List<Integer>> usageMap = new HashMap<>();
        
        for (Token token : tokens) {
            if (token.type.equals("Identifier") && symbolTable.containsKey(token.value)) {
                String identifier = token.value;
                if (!usageMap.containsKey(identifier)) {
                    usageMap.put(identifier, new ArrayList<>());
                }
                if (!usageMap.get(identifier).contains(token.lineNumber)) {
                    usageMap.get(identifier).add(token.lineNumber);
                }
            }
        }
        
        for (SymbolTableEntry entry : symbolTable.values()) {
            if (usageMap.containsKey(entry.identifier)) {
                List<Integer> usageLines = usageMap.get(entry.identifier);
                if (usageLines.size() == 1 && usageLines.get(0) == entry.declarationLine) {
                    usageLines.clear();
                }
                entry.usageLines = new ArrayList<>(usageLines);
            }
        }
    }

    private JTextArea createLineNumberComponent(JTextPane textPane) {
        JTextArea lineNumbers = new JTextArea("1");
        lineNumbers.setEditable(false);
        lineNumbers.setBackground(Color.DARK_GRAY);
        lineNumbers.setForeground(Color.LIGHT_GRAY);
        lineNumbers.setFont(new Font("Monospaced", Font.PLAIN, 12));

        textPane.getDocument().addDocumentListener(new DocumentListener() {
            private void updateLineNumbers() {
                SwingUtilities.invokeLater(() -> {
                    StringBuilder lines = new StringBuilder();
                    int lineCount = textPane.getDocument().getDefaultRootElement().getElementCount();
                    for (int i = 1; i <= lineCount; i++) {
                        lines.append(i).append(System.lineSeparator());
                    }
                    lineNumbers.setText(lines.toString());
                });
            }

            @Override public void insertUpdate(DocumentEvent e) { updateLineNumbers(); }
            @Override public void removeUpdate(DocumentEvent e) { updateLineNumbers(); }
            @Override public void changedUpdate(DocumentEvent e) { updateLineNumbers(); }
        });

        return lineNumbers;
    }

    private void updateStatus() {
        String text = inputArea.getText();
        int charCount = text.length();
        int wordCount = text.trim().isEmpty() ? 0 : text.trim().split("\\s+").length;
        int lineCount = text.split("\n").length;
        statusBar.setText(" Words: " + wordCount + " | Chars: " + charCount + " | Lines: " + lineCount);
    }

    private void showHelp() {
        String helpText = "Java Scanner GUI Help\n\n" +
                "1. Open a text file containing Java code using the 'Open' option in the 'File' menu.\n" +
                "2. Edit the code in the input area if needed.\n" +
                "3. Click the 'Scan' button to scan the code and display the tokens and symbol table.\n" +
                "4. Click the 'Syntax Analysis' button to check for syntax errors.\n" +
                "5. Use the 'Save' or 'Save As' options to save your changes.\n" +
                "6. View the tokens, symbol table, and syntax analysis results in the output tabs.\n\n" +
                "7. Use the 'Output' button in the status bar to show/hide the output panel.\n" +
                "8. Drag the divider between input and output panels to resize them.\n\n" +
                "For more information, refer to the user manual.";

        JOptionPane.showMessageDialog(frame, helpText, "Help", JOptionPane.INFORMATION_MESSAGE);
    }

    private class SyntaxHighlighter implements DocumentListener {
        public void insertUpdate(DocumentEvent e) { highlight(e); }
        public void removeUpdate(DocumentEvent e) { highlight(e); }
        public void changedUpdate(DocumentEvent e) {}

        private void highlight(DocumentEvent e) {
            SwingUtilities.invokeLater(() -> {
                try {
                    String text = inputArea.getText();
                    StyledDocument doc = inputArea.getStyledDocument();
                    Style defaultStyle = inputArea.getStyle(StyleContext.DEFAULT_STYLE);
                    Style keywordStyle = doc.addStyle("Keyword", null);
                    StyleConstants.setForeground(keywordStyle, Color.BLUE);

                    doc.setCharacterAttributes(0, text.length(), defaultStyle, true);

                    List<int[]> excludedRanges = new ArrayList<>();
                    excludedRanges.addAll(getCommentRanges(text));
                    excludedRanges.addAll(getStringRanges(text));

                    for (String word : KEYWORDS) {
                        int index = text.indexOf(word);
                        while (index >= 0) {
                            if (!isInExcludedRange(index, word.length(), excludedRanges)) {
                                doc.setCharacterAttributes(index, word.length(), keywordStyle, false);
                            }
                            index = text.indexOf(word, index + word.length());
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
        }

        private List<int[]> getCommentRanges(String text) {
            List<int[]> ranges = new ArrayList<>();
            int commentStart = text.indexOf("//");
            while (commentStart >= 0) {
                int commentEnd = text.indexOf("\n", commentStart);
                if (commentEnd == -1) {
                    commentEnd = text.length();
                }
                ranges.add(new int[]{commentStart, commentEnd});
                commentStart = text.indexOf("//", commentEnd);
            }

            commentStart = text.indexOf("/*");
            while (commentStart >= 0) {
                int commentEnd = text.indexOf("*/", commentStart);
                if (commentEnd == -1) {
                    commentEnd = text.length();
                } else {
                    commentEnd += 2;
                }
                ranges.add(new int[]{commentStart, commentEnd});
                commentStart = text.indexOf("/*", commentEnd);
            }
            return ranges;
        }

        private List<int[]> getStringRanges(String text) {
            List<int[]> ranges = new ArrayList<>();
            int stringStart = text.indexOf("\"");
            while (stringStart >= 0) {
                int stringEnd = text.indexOf("\"", stringStart + 1);
                if (stringEnd == -1) {
                    stringEnd = text.length();
                } else {
                    stringEnd += 1;
                }
                ranges.add(new int[]{stringStart, stringEnd});
                stringStart = text.indexOf("\"", stringEnd);
            }
            return ranges;
        }

        private boolean isInExcludedRange(int start, int length, List<int[]> excludedRanges) {
            int end = start + length;
            for (int[] range : excludedRanges) {
                if (start >= range[0] && end <= range[1]) {
                    return true;
                }
            }
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ScannerGUI::new);
    }
}

class Token {
    String type, value;
    int lineNumber;  // Add this line
    
    public Token(String type, String value, int lineNumber) {  // Update constructor
        this.type = type;
        this.value = value;
        this.lineNumber = lineNumber;
    }
    
    // Keep the existing toString() method
    @Override
    public String toString() {
        return type + "\t" + value;
    }
}

class SymbolTableEntry {
    String identifier;
    String type;
    String value;  // This stores the variable's initial value
    int size;
    int dimension;
    int declarationLine;
    List<Integer> usageLines = new ArrayList<>();
    int address;

    // Constructor with value parameter
    public SymbolTableEntry(String identifier, String type, String value, 
                          int size, int dimension, int declarationLine, int address) {
        this.identifier = identifier;
        this.type = type;
        this.value = value;
        this.size = size;
        this.dimension = dimension;
        this.declarationLine = declarationLine;
        this.address = address;
    }
}