<?php

$connection = mysqli_connect('localhost', 'root', '', 'book_db');

if (isset($_POST['send'])) {
    // Insert data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $location = $_POST['location'];
    $guests = $_POST['guests'];
    $arrivals = $_POST['arrivals'];
    $leaving = $_POST['leaving'];

    $request = "INSERT INTO book_form (name, email, phone, address, location, guests, arrivals, leaving) VALUES ('$name', '$email', '$phone', '$address', '$location', '$guests', '$arrivals', '$leaving')";
    mysqli_query($connection, $request);
    session_start();
    $_SESSION['success_message'] = "Booking done successfully.";
    header('location:book.php');
} elseif (isset($_POST['delete'])) {
    // Delete data
    $id = $_POST['id'];

    $request = "DELETE FROM book_form WHERE id=$id";
    mysqli_query($connection, $request);
    session_start();
    $_SESSION['success_message'] = "Your booking is deleted.";
    header('location:book.php');
} else {
    echo 'Something went wrong, please try again!';
}

?>